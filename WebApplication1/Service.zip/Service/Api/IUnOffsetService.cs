﻿namespace WebApplication1.Service.Api
{
    public interface IUnOffsetService
    {

    }
}
