using WebApplication1.Common;
using WebApplication1.Common.UnOffsetFile;

public class UnOffsetService
{
    private readonly MyDbContext _context;
    private readonly UnOffsetAccsum _unOffsetAccsum;

    public UnOffsetService(MyDbContext context, UnOffsetAccsum unOffsetAccsum)
    {
        _context = context;
        _unOffsetAccsum = unOffsetAccsum;
    }

    public async Task<UnOffsetAccsum> GetUnOffsetAccsumAsync(List<UnOffset> list)
    {
        return _unOffsetAccsum.GetUnOffsetAccsum(list);
    }

    public async Task<UnOffsetAccsum> GetUnOffsetAccsumFailed(string errcode, string errmsg)
    {
        return _unOffsetAccsum.GetFailedUnOffsetAccsum(errcode, errmsg);
    }
}