﻿namespace WebApplication1.Service.Dtos
{
    public class UnOffsetDtos
    {
    }
}
