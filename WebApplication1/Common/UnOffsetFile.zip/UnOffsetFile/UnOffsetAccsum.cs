﻿namespace WebApplication1.Common.UnOffsetFile
{
    public class UnOffsetAccsum
    {
        public string errcode { get; set; }
        public string errmsg { get; set; }
        public decimal? bqty { get; set; }
        public decimal? cost { get; set; }
        public decimal? marketvalue { get; set; }
        public decimal? profit { get; set; }
        public string pl_ratio { get; set; }
        public decimal? fee { get; set; }
        public decimal? tax { get; set; }
        public decimal? estimateAmt { get; set; }
        public decimal? estimateFee { get; set; }
        public decimal? estimateTax { get; set; }
        public List<UnOffsetSum> unoffset_qtype_sum { get; set; }

        //獲取國內證券-未實現損益 帳號彙總
        public UnOffsetAccsum GetUnOffsetAccsum(List<UnOffset> list)
        {
            Logger.Log(0, "開始", $"開始獲取國內證券-未實現損益 帳號彙總");
            UnOffsetAccsum unoffset_qtype_accsum = new UnOffsetAccsum();
            try
            {
                //使用errorHandler來存放錯誤訊息
                ErrorHandler errorHandler = (errorCode, errorMessage) =>
                {
                    unoffset_qtype_accsum.errcode = errorCode;
                    unoffset_qtype_accsum.errmsg = errorMessage;
                };

                //獲得每支股票的未實現損益的List
                UnOffsetSum unOffsetSum = new UnOffsetSum();
                List<UnOffsetSum> unOffsetSums = unOffsetSum.GetUnOffsetSumList(list, errorHandler);
                //當GetUnOffsetSum或是GetUnOffsetDetail出現問題時會回傳null，因為訊息已經寫好，所以直接回傳只存放有錯誤訊息的
                if (unOffsetSums == null)
                {
                    return unoffset_qtype_accsum;
                }

                //透過list的加總功能加總每一項
                var bqty = unOffsetSums.Sum(t => t.bqty);
                var cost = unOffsetSums.Sum(t => t.cost);
                var marketvalue = unOffsetSums.Sum(t => t.marketvalue);
                var profit = unOffsetSums.Sum(t => t.profit);

                //在UnOffsetDetail已經有對pl_ratio做錯誤log的紀錄了，所以只在裡面記錄一次
                string pl_ratio;
                if (cost != 0m)
                {
                    pl_ratio = ((profit / cost) * 100).ToString() + "%";
                }
                else
                {
                    pl_ratio = "NAN%";
                }

                var fee = unOffsetSums.Sum(t => t.fee);
                var tax = unOffsetSums.Sum(t => t.tax);
                var estimateAmt = unOffsetSums.Sum(t => t.estimateAmt);
                var estimateFee = unOffsetSums.Sum(t => t.estimateFee);
                var estimateTax = unOffsetSums.Sum(t => t.estimateTax);

                //如果都沒問題就將errcode設為0000，errmsg設為成功
                var errcode = "0000";
                var errmsg = "成功";

                unoffset_qtype_accsum = new UnOffsetAccsum
                {
                    errcode = errcode,
                    errmsg = errmsg,
                    bqty = bqty,
                    cost = cost,
                    marketvalue = marketvalue,
                    profit = profit,
                    pl_ratio = pl_ratio,
                    fee = fee,
                    tax = tax,
                    estimateAmt = estimateAmt,
                    estimateFee = estimateFee,
                    estimateTax = estimateTax,
                    unoffset_qtype_sum = unOffsetSums
                };
                Logger.Log(0, "成功", "國內證券-未實現損益 帳號彙總獲取成功");
                return unoffset_qtype_accsum;
            }
            catch (Exception ex)
            {
                unoffset_qtype_accsum.errcode = "500";
                unoffset_qtype_accsum.errmsg = "國內證券-未實現損益 帳號彙總獲取失敗";
                unoffset_qtype_accsum.unoffset_qtype_sum = [];

                Logger.Log(4, "失敗", $"國內證券-未實現損益 帳號彙總獲取失敗，錯誤訊息：{ex.Message}");

                return unoffset_qtype_accsum;
            }
        }
        //讓一開始就出錯也能回傳錯誤訊息
        public UnOffsetAccsum GetFailedUnOffsetAccsum(string errcode, string errmsg)
        {
            UnOffsetAccsum unoffset_qtype_accsum = new UnOffsetAccsum();

            unoffset_qtype_accsum.errcode = errcode;
            unoffset_qtype_accsum.errmsg = errmsg;
            unoffset_qtype_accsum.unoffset_qtype_sum = [];

            return unoffset_qtype_accsum;
        }

    }














}
