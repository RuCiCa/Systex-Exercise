﻿using Microsoft.Identity.Client;

using WebApplication1.Util;


namespace WebApplication1.Common.UnOffsetFile
{
    public class UnOffsetDetailBase
    {
        public string tdate { get; set; }
        public string ttype { get; set; }
        public string ttypename { get; set; }
        public string bstype { get; set; }
        public string dseq { get; set; }
        public string dno { get; set; }
        public decimal? bqty { get; set; }
        public decimal? mprice { get; set; }
        public decimal? mamt { get; set; }
        public decimal? lastprice { get; set; }
        public decimal? marketvalue { get; set; }
        public decimal? fee { get; set; }
        public decimal? tax { get; set; }
        public decimal? cost { get; set; }
        public decimal? estimateAmt { get; set; }
        public decimal? estimateFee { get; set; }
        public decimal? estimateTax { get; set; }
        public decimal? profit { get; set; }
        public string pl_ratio { get; set; }

        //計算個股底下的單張委託書的未實現損益
        public UnOffsetDetailBase GetUnOffsetDetail(UnOffset unOffset, ErrorHandler errorHandler)
        {
            TCNUD tcnud = unOffset.TCNUD;
            Logger.Log(0, "開始", $"開始計算{unOffset.CNAME}之未實現損益 – 個股明細，委託書號{tcnud.DSEQ}-分單號碼{tcnud.DNO}");
            try
            {
                decimal? bqty = tcnud.BQTY;
                decimal? mprice = tcnud.PRICE;
                decimal? mamt = bqty * mprice;
                decimal? lastprice = unOffset.CPRICE;
                decimal? cost = tcnud.COST;
                decimal? estimateAmt = lastprice * tcnud.BQTY;
                decimal estFee = 0.001425m;
                decimal estTax = 0.003m;
                Logger.Log(2, "變數", $"手續費為：{estFee}, 稅率為：{estTax}");
                decimal? estimateFee = estimateAmt * estFee;
                decimal? estimateTax = estimateAmt * estTax;
                decimal? marketvalue = estimateAmt - estimateFee - estimateTax;
                decimal? profit = marketvalue - cost;
                string pl_ratio;

                if (cost != 0m)
                {
                    pl_ratio = ((profit / cost) * 100).ToString() + "%";
                }
                else
                {
                    Logger.Log(3, "警告", "cost為0，無法計算pl_ratio");
                    pl_ratio = "NAN%";
                }

                UnOffsetDetailBase unOffsetDetail = new UnOffsetDetailBase()
                {
                    tdate = tcnud.TDATE,
                    ttype = "0",
                    ttypename = "現買",
                    bstype = "B",
                    dseq = tcnud.DSEQ,
                    dno = tcnud.DNO,
                    bqty = bqty,
                    mprice = mprice,
                    mamt = mamt,
                    lastprice = lastprice,
                    marketvalue = marketvalue,
                    fee = tcnud.FEE,
                    tax = 0,
                    cost = cost,
                    estimateAmt = estimateAmt,
                    estimateFee = estimateFee,
                    estimateTax = estimateTax,
                    profit = profit,
                    pl_ratio = pl_ratio
                };
                Logger.Log(0, "成功", $"{unOffset.CNAME}之未實現損益 – 個股明細，委託書號{tcnud.DSEQ}-分單號碼{tcnud.DNO}計算成功");
                return unOffsetDetail;
            }
            //透過errorHandler來處理errcode跟errmsg
            catch (Exception ex)
            {
                errorHandler("500", $"計算{unOffset.CNAME}之未實現損益 – 個股明細，委託書號{tcnud.DSEQ}-分單號碼{tcnud.DNO}時出現錯誤");
                Logger.Log(4, "失敗", $"錯誤訊息: {ex}");
                return null;
            }
        }
        //獲取單一股票底下的所有委託的未實現損益List
        public Dictionary<string[], List<UnOffsetDetailBase>> GetUnOffsetDetailDict(List<UnOffset> list, ErrorHandler errorHandler)
        {
            //建立一個dict，然後使用StringArrayComparer來對作為key的string[]檢查
            var unOffsetDetailDict = new Dictionary<string[], List<UnOffsetDetailBase>>(new StringArrayComparer());


            foreach (var unOffset in list)
            {
                var unOffsetDetail = GetUnOffsetDetail(unOffset, errorHandler);
                var cName = unOffset.CNAME;
                var stock = unOffset.TCNUD.STOCK;

                if (unOffsetDetail == null)
                {
                    return null;
                }
                try
                {
                    //用stock跟cName當作鍵位
                    string[] key = [stock, cName];
                    //檢查key值有沒有重複，透過StringArrayComparer()
                    if (!unOffsetDetailDict.ContainsKey(key))
                    {
                        Console.WriteLine($"unOffsetDetailDict沒有key{key}");
                        unOffsetDetailDict[key] = new List<UnOffsetDetailBase>();
                    }
                    unOffsetDetailDict[key].Add(unOffsetDetail);
                }
                catch (Exception ex)
                {
                    Logger.Log(4, "失敗", $"錯誤訊息: {ex}");
                    errorHandler("500", $"計算{cName}之個股未實現損益時出現錯誤");
                    return null;
                }
            }


            return unOffsetDetailDict;
        }
    }

}
