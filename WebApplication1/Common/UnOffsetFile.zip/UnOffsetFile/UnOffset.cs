﻿namespace WebApplication1.Common.UnOffsetFile
{
    public class UnOffset
    {
        public TCNUD TCNUD { get; set; }
        public string CNAME { get; set; }
        public decimal? CPRICE { get; set; }
    }
}
