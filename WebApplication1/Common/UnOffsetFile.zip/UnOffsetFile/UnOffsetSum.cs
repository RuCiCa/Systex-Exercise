﻿using System.Collections.Generic;
using static Azure.Core.HttpHeader;

namespace WebApplication1.Common.UnOffsetFile
{
    public class UnOffsetSum
    {
        public string stock { get; set; }
        public string stocknm { get; set; }
        public string ttype { get; set; }
        public string ttypename { get; set; }
        public string bstype { get; set; }
        public decimal? bqty { get; set; }
        public decimal? cost { get; set; }
        public decimal? avgprice { get; set; }
        public decimal? lastprice { get; set; }
        public decimal? marketvalue { get; set; }
        public decimal? estimateAmt { get; set; }
        public decimal? estimateFee { get; set; }
        public decimal? estimateTax { get; set; }
        public decimal? profit { get; set; }
        public string pl_ratio { get; set; }
        public decimal? fee { get; set; }
        public decimal? tax { get; set; }
        public decimal? amt { get; set; }
        public List<UnOffsetDetailBase> unoffset_qtype_detail { get; set; }

        public UnOffsetSum GetUnOffsetSum(string[] key, List<UnOffsetDetailBase> value, ErrorHandler errorHandler)
        {
            string stock = key[0];
            string stocknm = key[1];
            try
            {
                decimal? bqty = value.Sum(t => t.bqty);
                decimal? cost = value.Sum(t => t.cost);
                decimal? avgprice = cost / bqty;
                decimal? marketvalue = value.Sum(t => t.marketvalue);
                decimal? estimateAmt = value.Sum(t => t.estimateAmt);
                decimal? estimateFee = value.Sum(t => t.estimateFee);
                decimal? estimateTax = value.Sum(t => t.estimateTax);
                decimal? profit = value.Sum(t => t.profit);
                decimal? fee = value.Sum(t => t.fee);
                decimal? tax = value.Sum(t => t.tax);
                decimal? amt = value.Sum(t => t.mamt);
                string pl_ratio;

                //UnOffsetDetail已經有做過錯誤log紀錄
                if (cost != 0m)
                {
                    pl_ratio = ((profit / cost) * 100).ToString() + "%";
                }
                else
                {
                    pl_ratio = "NAN%";
                }

                UnOffsetSum unOffsetSum = new UnOffsetSum()
                {
                    stock = stock,
                    stocknm = stocknm,
                    ttype = "0",
                    ttypename = "現買",
                    bstype = "B",
                    bqty = bqty,
                    cost = cost,
                    avgprice = avgprice,
                    lastprice = value.FirstOrDefault()?.lastprice,
                    marketvalue = marketvalue,
                    estimateAmt = estimateAmt,
                    estimateFee = estimateFee,
                    estimateTax = estimateTax,
                    profit = profit,
                    pl_ratio = pl_ratio,
                    fee = fee,
                    tax = tax,
                    amt = amt,
                    unoffset_qtype_detail = value
                };

                return unOffsetSum;
            }
            catch (Exception ex)
            {
                Logger.Log(4, "失敗", $"錯誤訊息: {ex}");
                errorHandler("500", $"計算{stocknm}個股未實現損益時出現錯誤");
                return null;
            }
        }

        //獲得所有個股未實現損益的List
        public List<UnOffsetSum> GetUnOffsetSumList(List<UnOffset> list, ErrorHandler errorHandler)
        {
            List<UnOffsetSum> unOffsetSums = new List<UnOffsetSum>();
            UnOffsetDetailBase unOffsetDetail = new UnOffsetDetailBase();
            Dictionary<string[], List<UnOffsetDetailBase>> unOffsetDetailDict = unOffsetDetail.GetUnOffsetDetailDict(list, errorHandler);
            //檢查是否為空值，因為UnOffsetDetail已經紀錄過錯誤訊息，所以如果為空值便直接回傳到最前面
            if (unOffsetDetailDict == null)
            {
                return null;
            }
            //根據一種股票一個個股未實現權益
            foreach (KeyValuePair<string[], List<UnOffsetDetailBase>> kvp in unOffsetDetailDict)
            {
                string[] key = kvp.Key;
                List<UnOffsetDetailBase> value = kvp.Value;
                Logger.Log(0, "開始", $"開始計算{key[1]}之個股未實現損益");
                try
                {
                    UnOffsetSum unOffsetSum = GetUnOffsetSum(key, value, errorHandler);
                    if (unOffsetSum == null)
                    {
                        return null;
                    }
                    unOffsetSums.Add(unOffsetSum);
                }
                catch(Exception ex)
                {
                    Logger.Log(4, "失敗", $"錯誤訊息: {ex}");
                    errorHandler("500", $"計算{key[1]}之個股未實現損益時出現錯誤");
                    return null;
                }
                Logger.Log(0, "成功", $"{key[1]}之個股未實現損益計算成功");
            }
            return unOffsetSums;
        }

    }




}
